
import { useState, useEffect } from "react";

export function useInView(ref, options = {}) {
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    if (!ref.current) return;

    const observer = new IntersectionObserver(([entry]) => {
      setIsInView(entry.isIntersecting);
      
      // If once is true and element is in view, unobserve
      if (options.once && entry.isIntersecting) {
        observer.unobserve(entry.target);
      }
    }, {
      root: options.root || null,
      rootMargin: options.rootMargin || "0px",
      threshold: options.threshold || 0
    });

    observer.observe(ref.current);

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, [ref, options.root, options.rootMargin, options.threshold, options.once]);

  return isInView;
}
