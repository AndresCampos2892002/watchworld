import React, { useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { CartProvider } from "@/components/cart-context";
import { Navbar } from "@/components/navbar";
import { CartDrawer } from "@/components/cart-drawer";
import { HeroSection } from "@/components/hero-section";
import { FeaturesSection } from "@/components/features-section";
import { SpecsSection } from "@/components/specs-section";
import { PricingSection } from "@/components/pricing-section";
import { ReviewsSection } from "@/components/reviews-section";
import { Footer } from "@/components/footer";

function App() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate");
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = document.querySelectorAll(".scroll-animation");
    elements.forEach((el) => observer.observe(el));

    return () => {
      elements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  return (
    <CartProvider>
      <div className="min-h-screen bg-background text-foreground">
        <Navbar />
        <CartDrawer />
        <main>
          <HeroSection />
          <FeaturesSection />
          <PricingSection /> 
          <SpecsSection />
          <ReviewsSection />
        </main>
        <Footer />
        <Toaster />
      </div>
    </CartProvider>
  );
}

export default App;