
import React from "react";
import { Button } from "@/components/ui/button";
import { Minus, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

const QuantitySelector = React.forwardRef(({ 
  className, 
  value = 1, 
  min = 1, 
  max = 99, 
  onChange,
  ...props 
}, ref) => {
  const handleDecrement = () => {
    if (value > min) {
      onChange(value - 1);
    }
  };

  const handleIncrement = () => {
    if (value < max) {
      onChange(value + 1);
    }
  };

  return (
    <div 
      className={cn("flex items-center rounded-md border", className)}
      ref={ref}
      {...props}
    >
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 rounded-r-none"
        onClick={handleDecrement}
        disabled={value <= min}
      >
        <Minus className="h-4 w-4" />
        <span className="sr-only">Decrease quantity</span>
      </Button>
      <div className="flex-1 text-center px-2 py-1 min-w-[40px]">
        {value}
      </div>
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 rounded-l-none"
        onClick={handleIncrement}
        disabled={value >= max}
      >
        <Plus className="h-4 w-4" />
        <span className="sr-only">Increase quantity</span>
      </Button>
    </div>
  );
});

QuantitySelector.displayName = "QuantitySelector";

export { QuantitySelector };
