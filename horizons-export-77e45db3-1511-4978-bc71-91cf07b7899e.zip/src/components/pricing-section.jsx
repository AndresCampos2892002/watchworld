import React, { useState } from "react";
import { motion } from "framer-motion";
import { Check, ShoppingCart, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/components/cart-context";
import { formatCurrency } from "@/lib/utils";

const products = [
  {
    id: "aero-x3000",
    name: "AeroGlide X3000",
    price: 1899,
    originalPrice: 2499,
    image: "https://images.unsplash.com/photo-1692346784393-ef486e6e263d",
    alt: "AeroGlide X3000 Smartwatch",
    rating: 5,
    reviews: 1200,
    features: [
      "Pantalla AMOLED de alta resolución",
      "Monitoreo avanzado de salud 24/7",
      "Batería de larga duración (hasta 7 días)",
      "Resistente al agua (5 ATM / IP68)",
      "GPS integrado de alta precisión",
    ],
    variants: [
      { id: "aero-x3000-black", name: "Negro Espacial", colorClass: "bg-black" },
      { id: "aero-x3000-silver", name: "Plata", colorClass: "bg-gray-300" },
      { id: "aero-x3000-blue", name: "Azul Océano", colorClass: "bg-blue-600" }
    ],
    tags: ["Nuevo Lanzamiento", "Más Vendido"]
  },
  {
    id: "chrono-elite-z5",
    name: "ChronoElite Z5",
    price: 2399,
    originalPrice: 2999,
    image: "https://images.unsplash.com/photo-1546868871-7041f2a55e12",
    alt: "ChronoElite Z5 Smartwatch",
    rating: 4.8,
    reviews: 950,
    features: [
      "Pantalla Super AMOLED curva",
      "Carga rápida inalámbrica",
      "ECG y monitor de presión arterial",
      "Caja de titanio aeroespacial",
      "Conectividad 5G opcional",
    ],
    variants: [
      { id: "chrono-z5-titanium", name: "Titanio Oscuro", colorClass: "bg-gray-700" },
      { id: "chrono-z5-gold", name: "Oro Rosado", colorClass: "bg-rose-400" }
    ],
    tags: ["Premium", "Tecnología Avanzada"]
  },
  {
    id: "aqua-sport-s1",
    name: "AquaSport S1",
    price: 1299,
    originalPrice: 1599,
    image: "https://images.unsplash.com/photo-1508685096489-7f78339349c9",
    alt: "AquaSport S1 Smartwatch",
    rating: 4.5,
    reviews: 780,
    features: [
      "Resistente al agua hasta 100m",
      "Modos de natación y buceo",
      "GPS para deportes acuáticos",
      "Correa de silicona deportiva",
      "Batería de 10 días",
    ],
    variants: [
      { id: "aqua-s1-ocean", name: "Azul Marino", colorClass: "bg-blue-800" },
      { id: "aqua-s1-coral", name: "Rojo Coral", colorClass: "bg-red-500" }
    ],
    tags: ["Deportivo", "Resistente"]
  },
  {
    id: "urban-style-u2",
    name: "UrbanStyle U2",
    price: 999,
    originalPrice: 1199,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30",
    alt: "UrbanStyle U2 Smartwatch",
    rating: 4.2,
    reviews: 620,
    features: [
      "Diseño minimalista y elegante",
      "Múltiples carátulas personalizables",
      "Notificaciones inteligentes",
      "Seguimiento básico de actividad",
      "Correa de cuero genuino",
    ],
    variants: [
      { id: "urban-u2-leather-brown", name: "Cuero Marrón", colorClass: "bg-yellow-700" },
      { id: "urban-u2-mesh-black", name: "Malla Negra", colorClass: "bg-gray-800" }
    ],
    tags: ["Elegante", "Urbano"]
  },
  {
    id: "fit-tracker-f10",
    name: "FitTracker F10",
    price: 799,
    originalPrice: 999,
    image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a",
    alt: "FitTracker F10 Smartband",
    rating: 4.0,
    reviews: 1150,
    features: [
      "Diseño ligero y compacto",
      "Monitor de actividad y sueño",
      "Recordatorios de sedentarismo",
      "Batería de hasta 14 días",
      "Resistente a salpicaduras",
    ],
    variants: [
      { id: "fit-f10-black", name: "Negro Clásico", colorClass: "bg-black" },
      { id: "fit-f10-pink", name: "Rosa Pastel", colorClass: "bg-pink-300" }
    ],
    tags: ["Fitness", "Básico"]
  }
];

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();
  const [selectedVariant, setSelectedVariant] = useState(product.variants[0]);

  const handleAddToCart = () => {
    addToCart({
      id: selectedVariant.id,
      name: `${product.name} - ${selectedVariant.name}`,
      price: product.price,
      variant: selectedVariant.name,
      image: product.image
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="h-full flex flex-col"
    >
      <Card className="border border-primary/20 overflow-hidden relative flex-grow flex flex-col">
        <div className="absolute top-0 right-0 z-10">
          {product.tags && product.tags.map(tag => (
            <Badge key={tag} className="rounded-none rounded-bl-lg mr-0.5">{tag}</Badge>
          ))}
        </div>
        
        <div className="relative aspect-square overflow-hidden">
          <img  
            alt={product.alt} 
            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
           src="https://images.unsplash.com/photo-1521051426148-4946df2795d4" />
        </div>

        <CardHeader className="pb-2 pt-4">
          <CardTitle className="text-xl md:text-2xl flex items-center justify-between">
            <span>{product.name}</span>
            <span className="text-gradient">{formatCurrency(product.price)}</span>
          </CardTitle>
          <div className="flex items-center space-x-1 text-sm text-muted-foreground">
            <Star className="h-4 w-4 fill-primary text-primary" />
            <span>{product.rating}</span>
            <span>({product.reviews} reseñas)</span>
          </div>
        </CardHeader>
        
        <CardContent className="pb-4 flex-grow">
          <div className="space-y-3">
            <div>
              <h4 className="font-medium text-sm mb-1">Características clave:</h4>
              <ul className="space-y-1 text-xs">
                {product.features.slice(0, 3).map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="h-4 w-4 text-primary shrink-0 mr-1.5 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-sm mb-2">Colores:</h4>
              <div className="flex space-x-2">
                {product.variants.map((variant) => (
                  <button
                    key={variant.id}
                    className={`w-6 h-6 rounded-full border-2 transition-all ${
                      selectedVariant.id === variant.id 
                        ? "border-primary scale-110 ring-2 ring-primary ring-offset-1 ring-offset-background" 
                        : "border-transparent hover:border-primary/50"
                    }`}
                    onClick={() => setSelectedVariant(variant)}
                    aria-label={`Color ${variant.name}`}
                  >
                    <span className={`block w-full h-full rounded-full ${variant.colorClass}`}></span>
                  </button>
                ))}
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                Seleccionado: <span className="font-medium">{selectedVariant.name}</span>
              </p>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="pt-0 mt-auto">
          <Button 
            size="default" 
            className="w-full"
            onClick={handleAddToCart}
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            Agregar al carrito
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};


export function PricingSection() {
  return (
    <section id="pricing" className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background -z-10"></div>
      <div className="absolute top-1/3 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-1/3 left-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -z-10"></div>
      
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Nuestra Colección de <span className="text-gradient">Smartwatches</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Explora nuestra gama de smartwatches, diseñados para cada estilo de vida y presupuesto.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}