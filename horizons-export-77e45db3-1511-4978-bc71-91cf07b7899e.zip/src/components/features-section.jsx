
import React, { useEffect, useRef } from "react";
import { motion, useAnimation } from "framer-motion";
import { useInView } from "@/hooks/use-in-view";
import { 
  Heart, 
  Battery, 
  Smartphone, 
  Droplets, 
  Watch, 
  Bluetooth 
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

const features = [
  {
    icon: Heart,
    title: "Monitoreo de salud",
    description: "Seguimiento avanzado de ritmo cardíaco, oxígeno en sangre y patrones de sueño con alertas personalizables."
  },
  {
    icon: Battery,
    title: "Batería de larga duración",
    description: "Hasta 7 días de uso con una sola carga, con modo de ahorro de energía inteligente."
  },
  {
    icon: Smartphone,
    title: "Conectividad perfecta",
    description: "Sincronización instantánea con tu smartphone para notificaciones, llamadas y control de aplicaciones."
  },
  {
    icon: Droplets,
    title: "Resistente al agua",
    description: "Certificación IP68 para uso bajo el agua hasta 50 metros de profundidad."
  },
  {
    icon: Watch,
    title: "Diseño premium",
    description: "Pantalla AMOLED de alta resolución con cristal de zafiro resistente a rayones."
  },
  {
    icon: Bluetooth,
    title: "Conectividad avanzada",
    description: "Bluetooth 5.2, NFC y GPS integrado para un rendimiento óptimo en cualquier situación."
  }
];

export function FeaturesSection() {
  const controls = useAnimation();
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, threshold: 0.2 });
  
  useEffect(() => {
    if (inView) {
      controls.start("visible");
    }
  }, [controls, inView]);
  
  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section id="features" className="py-20 bg-background relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500"></div>
      <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl"></div>
      <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl"></div>
      
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Características <span className="text-gradient">Excepcionales</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Descubre por qué el AeroGlide X3000 está revolucionando el mercado de los smartwatches con su tecnología de vanguardia.
          </p>
        </div>
        
        <motion.div 
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={controls}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {features.map((feature, index) => (
            <motion.div key={index} variants={itemVariants} className="feature-card">
              <Card className="h-full border border-border/50 bg-background/50 backdrop-blur-sm">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
