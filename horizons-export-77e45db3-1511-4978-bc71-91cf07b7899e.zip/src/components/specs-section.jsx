
import React, { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Badge } from "@/components/ui/badge";

export function SpecsSection() {
  const sectionRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"]
  });
  
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);
  const y = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [100, 0, 0, -100]);
  
  const specs = [
    { category: "Pantalla", value: "AMOLED 1.4\" (454 x 454 px)" },
    { category: "Procesador", value: "Dual-core 1.2 GHz" },
    { category: "Memoria", value: "1GB RAM + 8GB almacenamiento" },
    { category: "Batería", value: "420mAh (hasta 7 días)" },
    { category: "Sensores", value: "Ritmo cardíaco, SpO2, acelerómetro, giroscopio, altímetro" },
    { category: "Resistencia al agua", value: "5 ATM / IP68" },
    { category: "Conectividad", value: "Bluetooth 5.2, Wi-Fi, NFC, GPS" },
    { category: "Compatibilidad", value: "Android 6.0+, iOS 12.0+" },
    { category: "Dimensiones", value: "45 x 45 x 10.7 mm" },
    { category: "Peso", value: "32g (sin correa)" },
    { category: "Material", value: "Aleación de aluminio, cristal de zafiro" },
    { category: "Colores disponibles", value: "Negro espacial, Plata, Azul océano" }
  ];

  return (
    <section id="specs" ref={sectionRef} className="py-20 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background/90 -z-10"></div>
      <div className="absolute top-0 left-1/4 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -z-10"></div>
      
      <motion.div 
        className="container mx-auto px-4"
        style={{ opacity, y }}
      >
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge variant="outline" className="mb-4">ESPECIFICACIONES TÉCNICAS</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Potencia y <span className="text-gradient">Precisión</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Cada detalle del AeroGlide X3000 ha sido diseñado para ofrecer un rendimiento excepcional.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <div className="relative">
            <div className="sticky top-24">
              <div className="glass-card rounded-3xl overflow-hidden shadow-xl">
                <img  
                  alt="AeroGlide X3000 Smartwatch Especificaciones" 
                  className="w-full h-auto"
                 src="https://images.unsplash.com/photo-1632414967409-af50cf753029" />
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            {specs.map((spec, index) => (
              <motion.div 
                key={index}
                className="border-b border-border/50 pb-4"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
              >
                <div className="flex justify-between items-start">
                  <h3 className="font-medium text-muted-foreground">{spec.category}</h3>
                  <p className="text-right font-semibold">{spec.value}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </section>
  );
}
