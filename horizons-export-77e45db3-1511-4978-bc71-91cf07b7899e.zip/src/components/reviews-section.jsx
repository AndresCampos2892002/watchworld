
import React, { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Star, Quote } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const reviews = [
  {
    name: "Carlos Méndez",
    location: "Ciudad de Guatemala",
    rating: 5,
    comment: "El mejor smartwatch que he tenido. La batería dura una semana completa y los sensores son extremadamente precisos. Vale cada quetzal invertido.",
    date: "Hace 2 semanas"
  },
  {
    name: "María Fernanda López",
    location: "Quetzaltenango",
    rating: 5,
    comment: "Increíble calidad de construcción y la pantalla es espectacular incluso bajo la luz directa del sol. El seguimiento de actividad física es muy preciso.",
    date: "Hace 1 mes"
  },
  {
    name: "Alejandro Ramírez",
    location: "Antigua Guatemala",
    rating: 4,
    comment: "Excelente reloj con muchas funciones útiles. La interfaz es intuitiva y la sincronización con mi teléfono es perfecta. Solo le falta más opciones de personalización.",
    date: "Hace 3 semanas"
  },
  {
    name: "Lucía Castillo",
    location: "Escuintla",
    rating: 5,
    comment: "Superó todas mis expectativas. El monitoreo de salud es muy completo y me ha ayudado a mejorar mis hábitos. La resistencia al agua es excelente para nadar.",
    date: "Hace 2 meses"
  },
  {
    name: "Roberto Guzmán",
    location: "Cobán",
    rating: 5,
    comment: "Compré este reloj para monitorear mi actividad física y ha sido una gran inversión. La precisión del GPS es impresionante y la duración de la batería es sobresaliente.",
    date: "Hace 1 semana"
  },
  {
    name: "Daniela Morales",
    location: "Puerto Barrios",
    rating: 4,
    comment: "Diseño elegante y moderno. Funciona perfectamente para el seguimiento de ejercicios y notificaciones. El único detalle es que la correa podría ser más cómoda.",
    date: "Hace 1 mes"
  }
];

export function ReviewsSection() {
  const sectionRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"]
  });
  
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);
  const y = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [100, 0, 0, -100]);

  return (
    <section id="reviews" ref={sectionRef} className="py-20 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background/90 -z-10"></div>
      <div className="absolute top-1/4 left-1/3 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-1/4 right-1/3 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -z-10"></div>
      
      <motion.div 
        className="container mx-auto px-4"
        style={{ opacity, y }}
      >
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Lo que dicen nuestros <span className="text-gradient">clientes</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Descubre por qué el AeroGlide X3000 está recibiendo excelentes reseñas en todo Guatemala.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((review, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full border border-border/50 bg-background/50 backdrop-blur-sm hover:border-primary/50 transition-colors">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-semibold">{review.name}</h3>
                      <p className="text-sm text-muted-foreground">{review.location}</p>
                    </div>
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-4 w-4 ${i < review.rating ? "fill-primary text-primary" : "text-muted-foreground"}`} 
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div className="mb-4 relative">
                    <Quote className="absolute -top-2 -left-2 h-6 w-6 text-primary/20" />
                    <p className="text-sm pl-4">{review.comment}</p>
                  </div>
                  
                  <div className="text-xs text-muted-foreground text-right">
                    {review.date}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}
