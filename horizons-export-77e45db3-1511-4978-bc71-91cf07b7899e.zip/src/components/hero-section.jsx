
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Star } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center pt-16 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 hero-gradient -z-10"></div>
      
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden -z-10">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 py-12 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Badge variant="secondary" className="mb-4">
              NUEVO LANZAMIENTO
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-4 leading-tight">
              AeroGlide X3000
              <span className="block text-gradient">Smartwatch Premium</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-lg">
              Experimenta el futuro en tu muñeca con el smartwatch más avanzado del mercado. Diseño elegante, rendimiento excepcional.
            </p>
            
            <div className="flex items-center space-x-2 mb-8">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-primary text-primary" />
                ))}
              </div>
              <span className="text-sm text-muted-foreground">
                Basado en más de 1,200 reseñas
              </span>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="group" asChild>
                <a href="#pricing">
                  Comprar ahora
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#features">Ver características</a>
              </Button>
            </div>
          </motion.div>
          
          <motion.div
            className="relative"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="relative mx-auto max-w-md">
              {/* Glow effect */}
              <div className="absolute inset-0 bg-blue-500/30 rounded-full blur-3xl"></div>
              
              {/* Product image */}
              <div className="relative glass-card rounded-3xl overflow-hidden shadow-2xl">
                <img  
                  alt="AeroGlide X3000 Smartwatch" 
                  className="w-full h-auto"
                 src="https://images.unsplash.com/photo-1692346784393-ef486e6e263d" />
              </div>
              
              {/* Floating badge */}
              <motion.div 
                className="absolute -top-4 -right-4 bg-primary text-white px-4 py-2 rounded-full font-bold shadow-lg"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6, duration: 0.5 }}
              >
                Q1,899.00
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
