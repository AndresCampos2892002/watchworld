import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Trash2, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/components/cart-context";
import { QuantitySelector } from "@/components/ui/quantity-selector";
import { formatCurrency } from "@/lib/utils";
import { toast } from "@/components/ui/use-toast";

export function CartDrawer() {
  const { 
    cart, 
    isCartOpen, 
    setIsCartOpen, 
    removeFromCart, 
    updateQuantity, 
    clearCart, 
    getCartTotal 
  } = useCart();

  const handleCheckout = () => {
    toast({
      title: "Pedido realizado",
      description: "¡Gracias por tu compra! Tu pedido ha sido procesado.",
    });
    clearCart();
    setIsCartOpen(false);
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          <motion.div
            className="fixed inset-0 bg-black/50 z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
          />

          <motion.div
            className="fixed top-0 right-0 h-full w-full sm:w-96 bg-background z-50 shadow-xl"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
          >
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between p-4 border-b">
                <h2 className="text-xl font-bold flex items-center">
                  <ShoppingBag className="mr-2 h-5 w-5" />
                  Carrito de compras
                </h2>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setIsCartOpen(false)}
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <div className="flex-1 overflow-y-auto p-4">
                {cart.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <ShoppingBag className="h-16 w-16 text-muted-foreground mb-4" />
                    <p className="text-lg font-medium">Tu carrito está vacío</p>
                    <p className="text-muted-foreground mt-1">
                      Agrega algunos productos para comenzar
                    </p>
                    <Button 
                      className="mt-4" 
                      onClick={() => setIsCartOpen(false)}
                    >
                      Continuar comprando
                    </Button>
                  </div>
                ) : (
                  <ul className="space-y-4">
                    {cart.map((item) => (
                      <motion.li 
                        key={item.id}
                        className="flex items-start space-x-4 border-b pb-4"
                        layout
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="h-20 w-20 rounded-md overflow-hidden bg-secondary flex-shrink-0">
                          <img 
                            alt={item.name} 
                            className="h-full w-full object-cover"
                           src="https://images.unsplash.com/photo-1675023112817-52b789fd2ef0" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-medium truncate">{item.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {formatCurrency(item.price)}
                          </p>
                          <div className="flex items-center mt-2">
                            <QuantitySelector
                              value={item.quantity}
                              onChange={(value) => updateQuantity(item.id, value)}
                              className="h-8 w-24"
                            />
                            <Button
                              variant="ghost"
                              size="icon"
                              className="ml-2 text-destructive"
                              onClick={() => removeFromCart(item.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="font-medium">
                            {formatCurrency(item.price * item.quantity)}
                          </span>
                        </div>
                      </motion.li>
                    ))}
                  </ul>
                )}
              </div>

              {cart.length > 0 && (
                <div className="border-t p-4 space-y-4">
                  <div className="flex items-center justify-between font-medium">
                    <span>Total</span>
                    <span>{formatCurrency(getCartTotal())}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Button 
                      variant="outline" 
                      onClick={clearCart}
                    >
                      Vaciar carrito
                    </Button>
                    <Button onClick={handleCheckout}>
                      Finalizar compra
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}